##Income_Analysis
# Karan Kianfar, Karankia@iastate.edu
#Nov-2025
#programming in GIS
#Code Sharing Assingment


#Modules 
import os
import arcpy
import pandas as pd
import matplotlib.pyplot as plt

#Parameters
#CSV File (Income CSV)
csv_file= arcpy.GetParameterAsText(0)
#GeoJSON
gjson_file = arcpy.GetParameterAsText(1)
#Output Feature Class
output_fc = arcpy.GetParameterAsText(2)
#GEOID in GEOJSON
fc_join_field = arcpy.GetParameterAsText(3)
#GEOID in CSV
csv_join_field = arcpy.GetParameterAsText(4)
#png location
graph_png = arcpy.GetParameterAsText(5)
display_option = arcpy.GetParameterAsText(6)

#Enviornment
arcpy.env.workspace = "in_memory"
arcpy.env.overwriteOutput = True
arcpy.AddMessage("How cool is that...")


##Convert to Feature Class and save in desire location
arcpy.AddMessage("Converting to Feature Class...")
temp_fc = "temp_fc"
arcpy.conversion.JSONToFeatures(gjson_file, temp_fc)
arcpy.CopyFeatures_management(temp_fc,output_fc)
arcpy.AddMessage(f"Feature class created at : {output_fc}")


## Loading CSV and Cleaning Percentage
arcpy.AddMessage("Loading CSV")
df = pd.read_csv(csv_file)
## Need to Clean % Sign
value_t = "Households—Total—Less than $10,000—Estimate"
value_c = df[value_t].str.replace("%", "")
value_c = value_c.replace("-", "0")
df["INC_LT10K_PCT"] = value_c.astype(float)

##CSV to GIS table
clean_csv = os.path.join(arcpy.env.scratchFolder, "income_table.csv")
df.to_csv(clean_csv, index = False)
csv_table = arcpy.TableToTable_conversion(clean_csv, "in_memory", "income_table")
arcpy.AddMessage("Joining income table to feature class...")
##Make a feature Layer from the output feature class
tracts_lyr="tracts_layer"
arcpy.management.MakeFeatureLayer (output_fc, tracts_lyr)
##add join to layer
arcpy.management.AddJoin(tracts_lyr, fc_join_field, csv_table, csv_join_field)
##Copy the joined layer to a new feature class
joined_fc = output_fc + "_joined_raw"
arcpy.management.CopyFeatures(tract_lyr, joined_fc)
arcpy.AddMessage("Join Complete")
final_fc = output_fc + "_final"
arcpy.management.CopyFeatures(joined_fc,final_fc)
##Adding new field
arcpy.AddField_management(final_fc,"INCOME", "DOUBLE")
# Find the joined income field name in final_fc
all_fields = [f.name for f in arcpy.ListFields(final_fc)]
income_join_field = None
for f in all_fields:
    if f.upper().endswith("INC_LT10K_PCT"):
        income_join_field = f
        break

if income_join_field is None:
    arcpy.AddError("Could not find joined income field (INC_LT10K_PCT) in the feature class.")
    arcpy.AddMessage(f"Available fields: {all_fields}")
    raise SystemExit

arcpy.AddMessage(f"Using joined income field: {income_join_field}")
##update values from joined table field
with arcpy.da.UpdateCursor(final_fc,["INCOME",income_join_field]) as cursor:
    for row in cursor:
        row[0] = row[1]
        cursor.updateRow(row)

##Create Histogram

arcpy.AddMessage("creating income histogram")
values = df["INC_LT10K_PCT"].dropna()

plt.figure(figsize=(8,5))
plt.hist(values, bins=10, edgecolor = "black")
plt.title("Percentage of HH with income less than 10,000")
plt.xlabel("percent of Households")
plt.ylabel("Number of Census Tracts")
plt.tight_layout()
plt.savefig(graph_png)
plt.close()

#Symbology
if display_option == "Gradient":
    arcpy.AddMessage(f"Gradient selected. In ArcGIS Pro, symbolize {final_fc} using: "
    "Graduated Colors → Field = INCOME → Natural Breaks (Jenks), 5 classes.")
else:
    arcpy.AddMessage("No gradient symbology option selected")

arcpy.AddMessage("Income_Analysis is Done")


